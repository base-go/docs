---
title: Api
description: Api documentation for Base Framework.
---

# REST API Reference
Comprehensive guide to Base Framework's REST API patterns and endpoints.
### Interactive API Documentation
Explore and test your API endpoints with our auto-generated Swagger documentation.
[
Open Swagger UI
](http://localhost:8100/swagger/)